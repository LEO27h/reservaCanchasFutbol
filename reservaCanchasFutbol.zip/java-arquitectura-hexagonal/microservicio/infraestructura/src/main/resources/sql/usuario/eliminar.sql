delete 
from usuario
where id = :id