select id,nombre,clave,fecha_creacion
from usuario